import React from "react";
import AccountLockedPage from "../page-layouts/account-locked/account-locked-page";

function AccountLocked({ fpi }) {
  return <AccountLockedPage fpi={fpi} />;
}

export default AccountLocked;
