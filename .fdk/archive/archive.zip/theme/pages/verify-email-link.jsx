import React from "react";
import VerifyEmailLinkPage from "../page-layouts/verify-email-link/verify-email-link-page";

function VerifyEmailLink({ fpi }) {
  return <VerifyEmailLinkPage fpi={fpi} />;
}

export default VerifyEmailLink;
