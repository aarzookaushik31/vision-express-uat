import React, { useState, useEffect } from "react";
import Slider from "react-slick";
import styles from "./store-details.less";
import placeholderImage from "../../assets/images/placeholder/Store-detail-placeholder-image.png";
import CardplaceholderImage from "../../assets/images/placeholder/Store-detail-placeholder-image.png";
import PhoneIcon from "../../assets/images/store-phone.svg";
import Purchase from "../../assets/images/store-purchase.svg";
import Eye from "../../assets/images/store-eye-test.svg";
import Repair from "../../assets/images/repairIcon.png";
import AddressIcon from "../../assets/images/store-location.svg";
import ClockIcon from "../../assets/images/store-clock.svg";
import ShareDesktopIcon from "../../assets/images/share-04.svg";
import ShareItem from "../../components/share-item/share-item";
import GoogleRating from "./store-ratings.jsx";

const NearbyStoreArrow = ({ className, style, onClick, previous = false }) => (
  <button
    type="button"
    className={className}
    style={style}
    onClick={onClick}
    aria-label={previous ? "Previous nearby stores" : "Next nearby stores"}
    disabled={!onClick}
  >
    <span aria-hidden="true">{previous ? "‹" : "›"}</span>
  </button>
);

const StoreDetails = ({
  store,
  map_api_key,
  defaultPhone,
  nearbyStores = [],
}) => {
  const [showSocialLinks, setShowSocialLinks] = useState(false);
  const [googleData, setGoogleData] = useState(null);

  if (!store) {
    return <div className={styles.error}>Store details not available.</div>;
  }

  const {
    store_name,
    store_image = [],
    store_address_line_1,
    store_address_line_2,
    store_city,
    store_state,
    store_pincode,
    store_latitude,
    store_longitude,
    store_longitutde,
    phone_number,
    store_timings,
  } = store;

  const latitude = store_latitude;
  const longitude = store_longitude || store_longitutde;

  // ---- Clean address ----
  const addressParts = [
    store_address_line_1,
    store_address_line_2,
    store_city,
    store_state,
    store_pincode,
  ];

  const toTitleCase = (str) =>
    str
      .toLowerCase()
      .replace(/\b\w/g, (char) => char.toUpperCase())
      .replace(/\s+/g, " ")
      .trim();

  const cleanAddress = addressParts
    .map((part) => part?.trim().replace(/,+$/, ""))
    .filter(Boolean)
    .join(", ")
    .replace(/,+/g, ",")
    .replace(/\s*,\s*/g, ", ")
    .replace(/\s{2,}/g, " ");

  const formattedAddress = toTitleCase(cleanAddress);

  const mapSrc = `https://www.google.com/maps?q=${latitude},${longitude}&hl=en&z=15&output=embed`;

  // ---- Phone ----
  let contactNumber = "";

  if (typeof phone_number === "object" && phone_number !== null) {
    contactNumber = `${phone_number.code ? `+${phone_number.code}-` : ""}${phone_number.number}`;
  } else if (typeof phone_number === "string" && phone_number.trim() !== "") {
    contactNumber = phone_number;
  } else if (typeof phone_number === "number") {
    contactNumber = String(phone_number);
  } else if (defaultPhone) {
    contactNumber = defaultPhone;
  }

  const isMobile = /Mobi|Android/i.test(navigator.userAgent);
  const description = `${store_name} - located at ${formattedAddress}. Visit us today for eye check-ups, eyewear, and more!`;

  const handleShare = async () => {
    if (navigator.share && isMobile) {
      try {
        await navigator.share({
          title: store_name,
          text: description,
          url: window.location.href,
        });
      } catch (error) {
        console.error("Sharing failed:", error);
      }
    } else {
      setShowSocialLinks(true);
    }
  };

  useEffect(() => {
    const fetchRatingsOnce = async () => {
      try {
        const maps = await new Promise((resolve, reject) => {
          if (window.google?.maps?.places) return resolve(window.google.maps);
          const script = document.createElement("script");
          script.src = `https://maps.googleapis.com/maps/api/js?key=${map_api_key}&libraries=places`;
          script.async = true;
          script.defer = true;
          script.onload = () =>
            window.google?.maps?.places
              ? resolve(window.google.maps)
              : reject("Google Maps not available");
          script.onerror = () => reject("Failed to load Google Maps");
          document.body.appendChild(script);
        });

        const service = new maps.places.PlacesService(
          document.createElement("div"),
        );
        const request = {
          query: `Vision Express ${formattedAddress}`,
          fields: ["place_id", "name", "formatted_address"],
        };

        service.findPlaceFromQuery(request, (results, status) => {
          if (status === maps.places.PlacesServiceStatus.OK && results.length) {
            const place = results[0];
            const detailsRequest = {
              placeId: place.place_id,
              fields: [
                "name",
                "rating",
                "user_ratings_total",
                "reviews",
                "photos",
                "url",
              ],
            };

            service.getDetails(detailsRequest, (details, status2) => {
              if (status2 === maps.places.PlacesServiceStatus.OK && details) {
                let googlePhoto = null;

                if (details.photos && details.photos.length > 0) {
                  googlePhoto = details.photos[0].getUrl({
                    maxWidth: 800,
                    maxHeight: 600,
                  });
                }

                setGoogleData({
                  url: details.url,
                  ratingData: {
                    name: details.name,
                    rating: details.rating || 0,
                    total: details.user_ratings_total || 0,
                  },
                  reviews: details.reviews || [],
                  photo: googlePhoto,
                });
              }
            });
          }
        });
      } catch (e) {
        console.error("Error preloading Google data:", e);
      }
    };

    if (map_api_key) fetchRatingsOnce();
  }, [formattedAddress, map_api_key]);

  let weekdayTiming = "";
  let weekendTiming = "";

  if (Array.isArray(store_timings)) {
    const weekday = store_timings.find((d) => d.weekday === "monday");
    const weekend = store_timings.find((d) => d.weekday === "sunday");

    if (weekday?.slots?.length) {
      const slot = weekday.slots[0];
      weekdayTiming = `${slot.opening.hour}:${slot.opening.minute
        .toString()
        .padStart(2, "0")} - ${slot.closing.hour}:${slot.closing.minute
        .toString()
        .padStart(2, "0")}`;
    }

    if (weekend?.slots?.length) {
      const slot = weekend.slots[0];
      weekendTiming = `${slot.opening.hour}:${slot.opening.minute
        .toString()
        .padStart(2, "0")} - ${slot.closing.hour}:${slot.closing.minute
        .toString()
        .padStart(2, "0")}`;
    }
  }

  return (
    <section className={styles.storeDetailsSection}>
      {/* Top Section */}
      <div className={styles.topSection}>
        <div className={styles.shareContainer}>
          <button
            type="button"
            aria-label="Share store"
            className={styles.shareIcon}
            onClick={handleShare}
          >
            <ShareDesktopIcon />
          </button>
          {showSocialLinks && (
            <ShareItem
              setShowSocialLinks={setShowSocialLinks}
              handleShare={handleShare}
              description={description}
            />
          )}
        </div>

        <div className={styles.imageCarousel}>
          <img
            src={store_image[0] || googleData?.photo || placeholderImage}
            alt={store_name}
          />
        </div>

        <div className={styles.infoBlock}>
          {googleData && (
            <GoogleRating preFetchedData={googleData} fetchReviews={false} />
          )}

          <h1 className={styles.storeName}>{store_name}</h1>
          <p className={styles.address}>
            <span className={styles.iconCircle} aria-hidden="true">
              <AddressIcon />
            </span>
            {formattedAddress}
          </p>
          {(weekdayTiming || weekendTiming) && (
            <p className={styles.timings}>
              <span className={styles.iconCircle} aria-hidden="true">
                <ClockIcon />
              </span>
              <span>
                {weekdayTiming && <>MON - FRI: {weekdayTiming}</>}
                {weekdayTiming && weekendTiming && " | "}
                {weekendTiming && <>SAT - SUN: {weekendTiming}</>}
              </span>
            </p>
          )}

          {contactNumber && (
            <div className={styles.phoneRow}>
              <span className={styles.iconCircle} aria-hidden="true">
                <PhoneIcon />
              </span>
              <a href={`tel:${contactNumber}`}>{contactNumber}</a>
            </div>
          )}

          {/* Services */}
          <div className={styles.servicesOffered}>
            <div className={styles.servicesGrid}>
              <div className={styles.serviceCard}>
                <div className={styles.iconCircle}>
                  <Purchase aria-hidden="true" />
                </div>
                <p>Purchase</p>
              </div>

              <div className={styles.serviceCard}>
                <div className={styles.iconCircle}>
                  <Eye aria-hidden="true" />
                </div>
                <p>Eye Test</p>
              </div>

              <div className={styles.serviceCard}>
                <div className={styles.iconCircle}>
                  <img src={Repair} alt="Repair" />
                </div>
                <p>Repair</p>
              </div>
            </div>
          </div>

          <div className={styles.actionButtons}>
            <a
              href={`/sections/book-an-eye-test?storeCode=${store.store_code}`}
              className={styles.primaryBtn}
            >
              Book Appointment
            </a>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent("Vision Express, " + formattedAddress)}`}
              target="_blank"
              rel="noreferrer"
              className={styles.outlineBtn}
            >
              Get Direction
            </a>
          </div>

          {/* Map Section */}
          <div className={styles.locationSection}>
            <h3>Location</h3>

            {latitude && longitude && (
              <iframe
                src={mapSrc}
                width="100%"
                height="280"
                title={`Location of ${store_name}`}
                style={{ border: 0, borderRadius: "8px" }}
                allowFullScreen
                loading="lazy"
              ></iframe>
            )}
          </div>

          {/* Reviews Section */}
          {googleData && (
            <GoogleRating preFetchedData={googleData} fetchReviews={true} />
          )}
        </div>
      </div>

      {/* Nearby Stores Section */}
      {nearbyStores.length > 0 && (
        <div className={styles.nearbyStoresSection}>
          <h3>More Stores Near You</h3>
          <Slider
            className={styles.nearbyStoreList}
            slidesToShow={2}
            slidesToScroll={1}
            arrows={true}
            prevArrow={<NearbyStoreArrow previous />}
            nextArrow={<NearbyStoreArrow />}
            dots={false}
            infinite={nearbyStores.length > 1}
            responsive={[
              {
                breakpoint: 769,
                settings: {
                  slidesToShow: 1,
                  adaptiveHeight: true,
                  arrows: false,
                  dots: nearbyStores.length > 1,
                },
              },
            ]}
          >
            {nearbyStores.map((s, idx) => {
              const imageUrl =
                (s.store_image && s.store_image[0]) || CardplaceholderImage;

              const addressParts = [
                s.store_address_line_1,
                s.store_address_line_2,
                s.store_city,
                s.store_state,
                s.store_pincode,
              ];

              const cleanAddr = addressParts
                .map((p) => p?.trim().replace(/,+$/, ""))
                .filter(Boolean)
                .join(", ")
                .replace(/,+/g, ",")
                .replace(/\s*,\s*/g, ", ")
                .replace(/\s{2,}/g, " ");

              const formattedAddr = toTitleCase(cleanAddr);

              const mapLink = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                "Vision Express, " + formattedAddr,
              )}`;

              let contactNumber = "";
              if (
                typeof s.phone_number === "object" &&
                s.phone_number !== null
              ) {
                contactNumber = `${s.phone_number.code ? `+${s.phone_number.code}-` : ""}${s.phone_number.number}`;
              } else if (
                typeof s.phone_number === "string" &&
                s.phone_number.trim() !== ""
              ) {
                contactNumber = s.phone_number;
              } else if (typeof s.phone_number === "number") {
                contactNumber = String(s.phone_number);
              } else if (defaultPhone) {
                contactNumber = defaultPhone;
              }

              return (
                <div key={s._id || idx}>
                  <div className={styles.nearbyStoreCard}>
                    <div className={styles.imageWrapper}>
                      <img
                        src={imageUrl}
                        alt={s.store_name}
                        className={styles.storeImage}
                      />
                      {Number(s.rating || s.store_rating || s.google_rating) >
                        0 && (
                        <span className={styles.ratingRow}>
                          {Number(
                            s.rating || s.store_rating || s.google_rating,
                          ).toFixed(1)}{" "}
                          Ratings
                        </span>
                      )}
                    </div>

                    <div className={styles.storeContent}>
                      <h4 className={styles.storeName}>{s.store_name}</h4>
                      <p className={styles.storeAddress}>
                        <span className={styles.iconCircle} aria-hidden="true">
                          <AddressIcon />
                        </span>
                        {formattedAddr}
                      </p>

                      <div className={styles.phonebookContainer}>
                        {contactNumber && (
                          <p>
                            <span
                              className={styles.iconCircle}
                              aria-hidden="true"
                            >
                              <PhoneIcon />
                            </span>
                            <a href={`tel:${contactNumber}`}>{contactNumber}</a>
                          </p>
                        )}
                      </div>

                      <div className={styles.buttonGroup}>
                        <a
                          href={`/sections/book-an-eye-test?storeCode=${s.store_code}`}
                          className={styles.directionBtn}
                        >
                          Book Appointment
                        </a>
                        <a
                          href={mapLink}
                          target="_blank"
                          rel="noreferrer"
                          className={styles.detailsBtn}
                          aria-label={`Get directions to ${s.store_name}`}
                        >
                          <span aria-hidden="true">→</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </Slider>
        </div>
      )}
    </section>
  );
};

export default StoreDetails;
