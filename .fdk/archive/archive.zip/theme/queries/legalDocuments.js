export const LEGAL_DATA = `
query applicationContent {
  applicationContent {
    legal_information {
      id
      application
      policy
      returns
      shipping
      tnc
    }
  }
}

`;
