import React, { useState } from "react";
import useHeader from "../components/header/useHeader";
import { CREATE_TICKET } from "../queries/supportQuery";
import { useSnackbar } from "../helper/hooks";
import Base64 from "crypto-js/enc-base64";
import Utf8 from "crypto-js/enc-utf8";
import { useFPI, useGlobalTranslation } from "fdk-core/utils";
import { getConfigFromProps } from "../helper/utils";
import { useLocation } from "react-router-dom";
import styles from "../styles/sections/custom-contact-us.less";
import ContactEmailIcon from "../assets/images/contact-email-icon.png";
import ContactPhoneIcon from "../assets/images/contact-phone-icon.png";
import ContactAddressIcon from "../assets/images/contact-address-icon.png";
import FormSubmitEye from "../assets/images/form-submit-eye-white.png";
import CloseIcon from "../assets/images/close.svg";

function Component({ props = {} }) {
  const fpi = useFPI();
  const { globalConfig, supportInfo, appInfo, contactInfo } = useHeader(fpi);
  const { t } = useGlobalTranslation("translation");
  const pageConfig = getConfigFromProps(props);
  const { showSnackbar } = useSnackbar();
  const location = useLocation();

  // Left-side image chosen from the editor
  const { image } = props;

  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [errors, setErrors] = useState({});

  const { email, phone } = supportInfo?.contact ?? {};
  const { active: emailActive = false, email: emailArray = [] } = email ?? {};
  const { active: phoneActive = false, phone: phoneArray = [] } = phone ?? {};

  const storeAddress = contactInfo?.address;
  const storeDescription = contactInfo?.description || appInfo?.description;

  const getPrefillData = (search) => {
    const params = new URLSearchParams(search);
    const sanitize = (val) =>
      decodeURIComponent(val || "")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/^"|"$/g, "")
        .trim();

    return {
      values: {
        name: sanitize(params.get("name")),
        phone: sanitize(params.get("phone")),
        email: sanitize(params.get("email")),
      },
    };
  };

  const validateField = (name, value) => {
    const nameRegex = /^[A-Za-z\s]+$/;
    const emailRegex = /^\S+@\S+\.\S+$/;
    const phoneRegex = /^\d{10}$/;

    let error = "";

    if (!value || value.trim() === "") {
      return "This field is required";
    }
    if (name === "name") {
      if (!nameRegex.test(value)) {
        error = "Please enter a valid name (letters only)";
      }
    }

    if (name === "phone") {
      if (!phoneRegex.test(value) || /^(\d)\1{9}$/.test(value)) {
        error = "Please enter a valid 10 digit mobile number";
      }
    }

    if (name === "email") {
      if (!emailRegex.test(value)) {
        error = "Please enter a valid email address";
      }
    }

    return error;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    const error = validateField(name, value);

    setErrors((prev) => ({
      ...prev,
      [name]: error,
    }));
  };

  const prefillData = getPrefillData(location.search);

  const [formData, setFormData] = useState({
    name: prefillData.values.name || "",
    phone: prefillData.values.phone || "",
    email: prefillData.values.email || "",
    comment: "",
  });

  const handleSubmitForm = () => {
    try {
      const newErrors = {};

      Object.keys(formData).forEach((field) => {
        if (field === "comment") return;

        const error = validateField(field, formData[field]);
        if (error) newErrors[field] = error;
      });
      if (Object.keys(newErrors).length) {
        setErrors(newErrors);
        return;
      }

      let finalText = "";

      if (formData.name)
        finalText += `<b>${t("resource.common.name")}: </b>${formData.name}<br>`;
      if (formData.phone)
        finalText += `<b>${t("resource.common.phone")}: </b>${formData.phone}<br>`;
      if (formData.email)
        finalText += `<b>${t("resource.common.email")}: </b>${formData.email}<br>`;
      if (formData.comment)
        finalText += `<b>${t("resource.common.message")}: </b>${formData.comment}<br>`;

      finalText = `<div>${finalText}</div>`;

      const wordArray = Utf8.parse(finalText);
      finalText = Base64.stringify(wordArray);

      const values = {
        addTicketPayloadInput: {
          _custom_json: {
            comms_details: {
              name: formData.name,
              email: formData.email,
              phone: formData.phone,
            },
          },
          category: "contact-us",
          content: {
            attachments: [],
            description: finalText,
            title: t("resource.header.contact_request"),
          },
          priority: "low",
        },
      };

      fpi
        .executeGQL(CREATE_TICKET, values)
        .then(() => {
          setShowSuccessMessage(true);
        })
        .catch(() => {
          showSnackbar(t("resource.common.error_message"), "error");
        });
    } catch (error) {
      console.error(error);
      showSnackbar(
        t("resource.common.error_occurred_submitting_form"),
        "error"
      );
    }
  };

  const closeDialog = () => {
    setShowSuccessMessage(false);
  };

  return (
    <div className={styles.contactPageContainer}>
      {/* LEFT: photo + contact details card */}
      <div className={styles.contactInfo}>
        {image?.value && (
          <img
            className={styles.heroImage}
            src={image.value}
            alt="Customer support"
          />
        )}

        <div className={styles.infoCard}>
          {emailActive && emailArray?.length > 0 && (
            <div className={styles.contactEmails}>
              {emailArray.map((item, idx) => (
                <a
                  href={`mailto:${item?.value}`}
                  className={styles.iconItemContainer}
                  key={`email-${idx}`}
                >
                  <img alt="email icon" src={ContactEmailIcon} />
                  <div>
                    <h2>{item?.key}</h2>
                    <p>{item?.value}</p>
                  </div>
                </a>
              ))}
            </div>
          )}

          {phoneActive && phoneArray?.length > 0 && (
            <div className={styles.contactPhones}>
              {phoneArray.map((item, idx) => (
                <a
                  href={`tel:${item?.number}`}
                  className={styles.iconItemContainer}
                  key={`phone-${idx}`}
                >
                  <img alt="phone icon" src={ContactPhoneIcon} />
                  <div>
                    <h2>{item?.key}</h2>
                    <p>
                      {`${item?.code ? `+${item.code}-` : ""}${item?.number}`}
                    </p>
                  </div>
                </a>
              ))}
            </div>
          )}

          {storeAddress && (
            <div className={styles.iconItemContainer}>
              <img alt="Address icon" src={ContactAddressIcon} />
              <div>
                <h2>Reliance Vision Express Private Limited</h2>
                <p className={styles.storeAddress}>
                  {storeAddress?.address_line?.join(", ")},
                  {storeAddress?.city}, {storeAddress?.pincode},
                  {storeAddress?.country}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* RIGHT: heading, description, form */}
      <div
        className={`${styles.contactFormContainer} ${
          showSuccessMessage ? styles.successBackground : ""
        }`}
      >
        {showSuccessMessage ? (
          <div className={styles.successWrapper}>
            <span className={styles.closeSuccessButton} onClick={closeDialog}>
              <CloseIcon className={styles.closeIcon} />
            </span>

            <img src={FormSubmitEye} />

            <h2 className={styles.success_message}>
              Thanks for Getting in Touch!
            </h2>
            <p>
              We've received your message and one of our team members will
              connect with you soon.
              <br />
              <br />
              We appreciate your patience and look forward to assisting you.
            </p>
          </div>
        ) : (
          <div className={styles.formInner}>
            <h1 className={styles.formTitle}>Get In Touch With Us</h1>

            {storeDescription && (
              <p className={styles.storeDescription}>{storeDescription}</p>
            )}

            <form
              className={styles.contactForm}
              noValidate
              onSubmit={(e) => {
                e.preventDefault();
                handleSubmitForm();
              }}
            >
              <div className={styles.inputFlexGroup}>
                <div className={styles.inputfieldcontainer}>
                  <label htmlFor="name">Full Name</label>
                  <input
                    type="text"
                    name="name"
                    placeholder="Enter your Full Name"
                    value={formData.name}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    required
                    className={styles.formInput}
                  />
                  {errors.name && (
                    <p className={styles.errorText}>{errors.name}</p>
                  )}
                </div>
                <div className={styles.inputfieldcontainer}>
                  <label htmlFor="phone">Contact Number</label>
                  <input
                    type="tel"
                    name="phone"
                    placeholder="Enter 10 digit mobile number"
                    value={formData.phone}
                    required
                    onChange={(e) => {
                      const value = e.target.value
                        .replace(/\D/g, "")
                        .slice(0, 10);

                      setFormData((prev) => ({
                        ...prev,
                        phone: value,
                      }));

                      setErrors((prev) => ({
                        ...prev,
                        phone: "",
                      }));
                    }}
                    onBlur={handleBlur}
                    maxLength={10}
                    pattern="[0-9]{10}"
                    className={styles.formInput}
                  />
                  {errors.phone && (
                    <p className={styles.errorText}>{errors.phone}</p>
                  )}
                </div>
              </div>
              <div className={styles.inputfieldcontainer}>
                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  name="email"
                  placeholder="Enter your Email address"
                  value={formData.email}
                  required
                  onChange={handleChange}
                  onBlur={handleBlur}
                  className={styles.formInput}
                />
                {errors.email && (
                  <p className={styles.errorText}>{errors.email}</p>
                )}
              </div>
              <div className={styles.inputfieldcontainer}>
                <label htmlFor="comment">Message</label>
                <textarea
                  name="comment"
                  placeholder="Leave a message"
                  rows={5}
                  value={formData.comment}
                  onChange={handleChange}
                  className={styles.formTextarea}
                />
              </div>
              <button type="submit" className={styles.submitButton}>
                Submit
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}

export const settings = {
  label: "Custom Contact Us",
  props: [
    { type: "image_picker", id: "image", label: "Left Side Image" },
    {
      type: "checkbox",
      id: "show_address",
      default: true,
      label: "t:resource.sections.contact_us.address",
    },
    {
      type: "checkbox",
      id: "show_phone",
      default: true,
      label: "t:resource.sections.contact_us.phone",
    },
    {
      type: "checkbox",
      id: "show_email",
      default: true,
      label: "t:resource.sections.contact_us.email",
    },
  ],
};

export default Component;